import { expect, test } from "@playwright/test";
import type { Page } from "@playwright/test";

const routes = [
  { name: "landing", path: "/" },
  { name: "about-teacher", path: "/about-teacher" },
  { name: "contact", path: "/contact" }
] as const;

type ViewportProof = {
  project: string;
  route: string;
  expected: { width: number; height: number };
  actual: { width: number; height: number };
  document: { width: number; height: number };
  direction: string;
};

async function collectViewportProof(page: Page): Promise<ViewportProof> {
  const proof = await page.evaluate(() => ({
    width: window.innerWidth,
    height: window.innerHeight,
    documentWidth: document.documentElement.scrollWidth,
    documentHeight: document.documentElement.scrollHeight,
    direction: document.documentElement.dir
  }));
  const expected = page.viewportSize();
  if (!expected) throw new Error("Playwright viewport is not configured");
  return {
    project: test.info().project.name,
    route: new URL(page.url()).pathname,
    expected,
    actual: { width: proof.width, height: proof.height },
    document: { width: proof.documentWidth, height: proof.documentHeight },
    direction: proof.direction
  };
}

test.describe("DEV-only cross-device visual QA", () => {
  for (const route of routes) {
    test(`${route.name} has viewport proof and no page overflow`, async ({ page }, testInfo) => {
      await page.goto(route.path, { waitUntil: "networkidle" });
      await page.evaluate(() => localStorage.setItem("abdrabo_language", "ar"));
      await page.reload({ waitUntil: "networkidle" });
      await expect(page.locator("body")).toBeVisible();

      const proof = await collectViewportProof(page);
      await testInfo.attach("viewport-proof.json", {
        body: JSON.stringify(proof, null, 2),
        contentType: "application/json"
      });

      expect(proof.actual).toEqual(proof.expected);
      expect(proof.document.width).toBeLessThanOrEqual(proof.actual.width);
      expect(proof.direction).toBe("rtl");

      await page.screenshot({
        path: testInfo.outputPath(`${route.name}.png`),
        fullPage: true
      });
    });
  }
});
